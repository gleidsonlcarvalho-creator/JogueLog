# JogueLog Vision V4.1 — Android

- `app/src/main/assets/index.html` = JogueLog Vision V4.1 original.
- WebView com JavaScript e DOM Storage habilitados.
- Seletor de vídeo (`input type=file accept=video/*`) suportado via WebChromeClient.
- INTERNET habilitada exclusivamente para recursos externos usados pelo HTML, como OCR/Tesseract quando acionado.
- Sem SDK de anúncios, login, analytics ou pagamentos nesta compilação.
