# JogueLog — revisão para Google Play (05/11/2026)

## Situação técnica
- applicationId: `br.com.carvalhodigital.joguelog`
- compileSdk: 36
- targetSdk: 36
- minSdk: 26
- versão: 1.1.0 / versionCode 2
- sem permissão INTERNET
- sem AD_ID
- sem anúncios, analytics, login ou pagamentos nesta versão
- backup do app desativado
- processamento local em WebView

## Declarações do Play Console compatíveis com esta versão
- App, categoria Educação
- Público-alvo: maiores de 18 anos
- Anúncios: não
- ID de publicidade: não
- Recursos financeiros: não
- Saúde: não
- App governamental: não
- Coleta/compartilhamento de dados: não, desde que o código permaneça sem SDKs/rede e sem novas integrações
- Login restrito: não

## Regra crítica: loterias e apostas
Esta edição deve permanecer estritamente informativa/educacional. Não adicionar compra de bilhetes, links ou botões para apostar, gestão de apostas/prêmios, pagamentos relacionados a sorteios, chamadas como “apostar agora”, promessas de lucro/acerto ou publicidade de jogos de azar sem nova revisão de política.

## Política de privacidade
O app contém política local e foi adicionada uma cópia em `public_web/privacy-policy.html` para hospedagem pública HTTPS. O Play Console exige URL pública acessível; hospede esse arquivo e use a URL final específica da política, não apenas a home do site.

## Termos
`public_web/terms-of-use.html` foi incluído como boa prática e para consistência com status de comerciante, embora esta versão não tenha venda dentro do app.

## Antes do primeiro AAB
1. Gerar AAB assinado com o mesmo applicationId.
2. Conferir que o bundle não contém permissões/SDKs não declarados.
3. Instalar e testar em dispositivo físico Android.
4. Tirar 4 screenshots reais após fechar o visual.
5. Hospedar política e termos em HTTPS.
6. Teste fechado: para contas pessoais novas, cumprir os requisitos mostrados pelo Play Console (atualmente 12 testadores por 14 dias consecutivos quando aplicável).
7. Só depois solicitar produção.

## Pendências fora deste ZIP
- URL pública da política/termos ainda precisa ser publicada no seu site.
- O projeto ainda não inclui Gradle Wrapper, e este ambiente não possui Gradle instalado; portanto o AAB não foi compilado aqui.
- A aprovação final depende da análise do Google Play.
