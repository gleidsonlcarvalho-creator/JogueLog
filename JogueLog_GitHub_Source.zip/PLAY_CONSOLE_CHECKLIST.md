# Checklist Play Console — JogueLog V1.1

- [x] Application ID: `br.com.carvalhodigital.joguelog`
- [x] targetSdk/compileSdk 36
- [x] Sem INTERNET, AD_ID ou permissões sensíveis nesta versão
- [x] Sem anúncios, analytics, login, pagamentos ou recursos financeiros
- [x] Política de privacidade dentro do app com contato `carvalhodigitalapps@gmail.com`
- [x] Termos de Uso dentro do app
- [x] Público-alvo: 18+
- [x] Categoria: Educação
- [x] Conteúdo: estatística descritiva; sem aposta, bilhete, pagamento, link para apostar ou promessa de prêmio
- [ ] Hospedar `public_web/privacy-policy.html` em URL HTTPS pública e colocar a URL no Play Console
- [ ] Hospedar `public_web/terms-of-use.html` se desejar usar o campo Termos de Serviço
- [ ] Gerar AAB assinado
- [ ] Testar AAB/APK em aparelho físico
- [ ] Produzir 4 screenshots reais 9:16 depois de fechar o visual
- [ ] Fazer teste fechado exigido pela conta antes de pedir produção
- [ ] Conferir novamente Data Safety após qualquer SDK, anúncio, login, backend ou analytics futuro
