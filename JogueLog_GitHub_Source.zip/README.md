# JogueLog Play Store Project V1.1 — revisado 05/11/2026

Projeto Android simples baseado em WebView local para a primeira versão pública do JogueLog.

## Identidade técnica
- package/applicationId: `br.com.carvalhodigital.joguelog`
- targetSdk/compileSdk: 36
- minSdk: 26
- versionName: 1.1.0
- versionCode: 2

## Privacidade
Esta versão não possui permissão INTERNET, anúncios, analytics, login, pagamentos ou backend. A política declara processamento local e contato `carvalhodigitalapps@gmail.com`.

Arquivos públicos para hospedagem:
- `public_web/privacy-policy.html`
- `public_web/terms-of-use.html`

## Limite de produto
O app é informativo e educacional. Não deve oferecer apostas, compra de bilhetes, pagamentos de loteria, links para apostar, gestão de prêmios ou alegações de previsão/garantia.

## Build
Este pacote não inclui Gradle Wrapper. Abra no Android Studio, sincronize com o Android Gradle Plugin configurado e gere um Android App Bundle assinado. Antes de enviar, confira o Manifest final do bundle e teste em dispositivo físico.

Leia `PLAY_STORE_STANDARD_REVIEW.md` e `PLAY_CONSOLE_CHECKLIST.md` antes de publicar.
