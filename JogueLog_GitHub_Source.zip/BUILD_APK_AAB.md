# JogueLog — compilação Android

Projeto preparado para Android Studio.

## APK de teste
1. Abra a pasta do projeto no Android Studio.
2. Aguarde o Gradle Sync terminar.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. Instale o APK de debug no aparelho para testar.

## AAB para Google Play
1. Build > Generate Signed App Bundle / APK.
2. Escolha Android App Bundle.
3. Crie/seleciona a chave de assinatura e guarde-a com segurança.
4. Gere a variante release.
5. Envie o .aab ao teste fechado do Google Play.

Package: br.com.carvalhodigital.joguelog
Min SDK: 26
Target/Compile SDK: 36
